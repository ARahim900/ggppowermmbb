import ALMDashboard from '@/components/alm/alm-dashboard'

export default function ALMPage() {
  return <ALMDashboard />
}
