import WaterAnalysisDashboard from '@/components/water-system/water-analysis-dashboard'

export default function WaterSystemPage() {
  return <WaterAnalysisDashboard />
}
